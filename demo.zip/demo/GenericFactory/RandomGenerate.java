package demo.GenericFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created by Administrator on 2019/5/9.
 */
public class RandomGenerate implements CreaterTem {

    private   Random  random=new Random();
    @Override
    public  List<? extends DemoTempParent> generate(int size, List<Class<? extends DemoTempParent>> temp) throws IllegalAccessException, InstantiationException {
        List<DemoTempParent> re=new ArrayList<>();
        Integer modelSize= temp.size();
        for(int i=0;i<size;i++){
            int tempInt=  random.nextInt(modelSize);
            Class<? extends DemoTempParent> tempClass=  temp.get(tempInt);
            re.add(tempClass.newInstance());
        }
        return re;
    }
}
