package demo.GenericFactory;

/**
 * Created by Administrator on 2019/5/9.
 */
public class Child1 implements DemoTempParent{


}
