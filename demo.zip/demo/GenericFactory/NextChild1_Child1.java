package demo.GenericFactory;

/**
 * Created by Administrator on 2019/5/9.
 */
public class NextChild1_Child1 extends Child1{
    static  public  class Factory implements GenericFactory<Class<NextChild1_Child1>>{
        @Override
        public  Class<NextChild1_Child1> creat() {
            return NextChild1_Child1.class;
        }
    }
}
