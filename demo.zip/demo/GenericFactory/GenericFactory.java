package demo.GenericFactory;

/**
 * Created by Administrator on 2019/5/9.
 */
//泛化的生成自身的工厂
public interface GenericFactory<T> {
    T creat();
}
