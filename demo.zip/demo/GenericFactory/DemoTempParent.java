package demo.GenericFactory;

/**
 * Created by Administrator on 2019/5/9.
 */
//用于标记的顶部接口
public interface DemoTempParent {
}
