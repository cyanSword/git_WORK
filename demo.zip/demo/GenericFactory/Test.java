package demo.GenericFactory;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by Administrator on 2019/5/10.
 */
public class Test {
    public static void  main(String[] args) throws IllegalAccessException, InstantiationException {
        RandomGenerate generate=new RandomGenerate();
        ChildListP childListP= new ChildListP();
        childListP.generateList(generate,10);
        List<? extends DemoTempParent> classList= childListP.reList();
       TypeCounter type=new TypeCounter(DemoTempParent.class);
        for (DemoTempParent ele:
             classList) {
                    type.count(ele);
        }

        Map<Class,Long> groupDemo= childListP.reList().stream().collect(Collectors.groupingBy(Object::getClass,Collectors.counting()));
        //lamda表达式分类，超类尚没有统计
        System.out.println(groupDemo.toString());
        //这里用到了think in java里面的工具类进行超类递归统计
        //实例的继承链如下：
       //                   ->Child1->NextChild1_Child1,NextChild1_Child2
        //DemoTempParent->
        //                  ->Child2->NextChild2_Child1,NextChild2_Child2
        System.out.print(type.toString());
    }
}
