package demo.GenericFactory;

/**
 * Created by Administrator on 2019/5/9.
 */
public class NextChild2_Child2 extends Child2 {
    static  public  class Factory implements GenericFactory<Class<NextChild2_Child2>>{
        @Override
        public Class<NextChild2_Child2> creat() {
            return NextChild2_Child2.class;
        }
    }
}
