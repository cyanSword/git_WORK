package demo.GenericFactory;

/**
 * Created by Administrator on 2019/5/9.
 */
public class NextChild2_Child1 extends Child1 {
    static  public  class Factory implements GenericFactory<Class<NextChild2_Child1>>{
        @Override
        public Class<NextChild2_Child1> creat() {
            return NextChild2_Child1.class;
        }
    }
}
