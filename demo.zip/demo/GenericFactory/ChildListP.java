package demo.GenericFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2019/5/10.
 */
public class ChildListP extends GenericTypeList {

    @Override
    public List<Class<? extends DemoTempParent>> templateRe() {
        Class<NextChild1_Child1> class1=new NextChild1_Child1.Factory().creat();
        Class<NextChild1_Child2> class2=new NextChild1_Child2.Factory().creat();
        Class<NextChild2_Child1> class3=new NextChild2_Child1.Factory().creat();
        Class<NextChild2_Child2> class4=new NextChild2_Child2.Factory().creat();
        List<Class<? extends DemoTempParent>> re=new ArrayList<>();
        re.add(class1);
        re.add(class2);
        re.add(class3);
        re.add(class4);
        return re;
    }
}
