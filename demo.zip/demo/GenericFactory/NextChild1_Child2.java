package demo.GenericFactory;

/**
 * Created by Administrator on 2019/5/9.
 */
public class NextChild1_Child2 extends Child2 {
    static  public  class Factory implements GenericFactory<Class<NextChild1_Child2>>{
        @Override
        public Class<NextChild1_Child2> creat() {
            return NextChild1_Child2.class;
        }
    }
}
