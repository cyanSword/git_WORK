package demo.GenericFactory;

import java.util.List;

/**
 * Created by Administrator on 2019/5/9.
 */

public abstract class GenericTypeList {
    protected List<? extends DemoTempParent> list;
    public  List<? extends DemoTempParent> reList(){
        return  list;
    }
    public abstract List<Class<? extends DemoTempParent>> templateRe();//抽象出方法怎么包含Class<? extends DemoTempParent>的列表
    public  void generateList(CreaterTem gen,int size) throws InstantiationException, IllegalAccessException {//CreaterTem为生成及填充Class列表的策略
      list=  gen.generate(size,templateRe());
    }
}
