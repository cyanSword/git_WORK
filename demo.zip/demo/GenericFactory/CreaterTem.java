package demo.GenericFactory;

import java.util.List;

/**
 * Created by Administrator on 2019/5/9.
 */
public interface CreaterTem {
    public List<? extends DemoTempParent> generate(int size,List<Class<? extends DemoTempParent>> temp) throws IllegalAccessException, InstantiationException;
}
