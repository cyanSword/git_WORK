package sample;

import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.ProgressBar;

/**
 * Created by Administrator on 2018/12/10.
 */
class FirstLineService extends Service<Integer> {
    Task<Integer> task = null;
    @Override
    protected void executeTask(Task<Integer> task) {
        super.executeTask(task);
    }


    @Override
    protected void ready() {
        super.ready();
    }

    Task reTask() {
        return new Task<Integer>() {
            @Override
            public Integer call() throws InterruptedException {
                final int max = 1000;
                int i = 0;
                for (i = 1; i <= max; i++) {
                    if (isCancelled()) {
                        break;
                    }

                    updateProgress(i, max);


                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException interrupted) {
                        if (isCancelled()) {
                            i = 0;
                            updateProgress(i, max);
                            updateMessage("Cancelled");
                            break;
                        }
                    }
                }
                return i;
            }


            @Override
            protected void succeeded() {
                super.succeeded();
                updateMessage("Done!");
            }

            @Override
            protected void cancelled() {
                super.cancelled();
                updateMessage("Cancelled!");
            }

            @Override
            protected void failed() {
                super.failed();
                updateMessage("Failed!");
            }
        };
    }



    FirstLineService() {
        task = reTask();
    }

    Task reCreate() {
        return task = reTask();
    }

    @Override
    protected Task<Integer> createTask() {
        return task;
    }
}