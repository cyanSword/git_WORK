package sample;

import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

public class Controller {
    Task task=null;
    FirstLineService firstLineService=null;
    boolean flag=false;//默认是否是 取消状态

    @FXML
    private Pane pane;
    @FXML
    private TreeView tv1;

    @FXML
    private ProgressBar p1;

    @FXML
    private TextField t1;

    @FXML
    public void onclick(ActionEvent actionEvent) {
        t1.setText("hello !!");
        if(firstLineService.finish){
            flag= false;firstLineService.finish=false;
            task=   firstLineService.reCreate();
            p1.progressProperty().bind(task.progressProperty());
            firstLineService.executeTask(task);
        }

        if(flag){//取消状态下的点击 重新开始任务
            flag= !flag;
             task=   firstLineService.reCreate();
            p1.progressProperty().bind(task.progressProperty());
            firstLineService.executeTask(task);
        }
        else {
            flag= !flag;
            task.cancel();

        }

    }


    void init(Task task,FirstLineService firstLineService) {
        this.task=task;
        this.firstLineService=firstLineService;
        p1.progressProperty().bind(task.progressProperty());



        // TreeItem名字和图标
        TreeItem<String> rootItem = new TreeItem<> ("Inbox");
        rootItem.setExpanded(true);
        // 每个Item下又可以添加新的Item
        for (int i = 1; i < 6; i++) {
            TreeItem<String> item = new TreeItem<> ("Message" + i);
            item.getChildren().add(new TreeItem<String>("第三级"));
            rootItem.getChildren().add(item);
        }
        // 创建TreeView
         tv1.setRoot(rootItem);

    }
}
