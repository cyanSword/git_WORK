package sample;

import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;

public class Controller {
    Task task=null;
    FirstLineService firstLineService=null;
    boolean flag=false;//默认是否是 取消状态

    @FXML
    private ProgressBar p1;

    @FXML
    private TextField t1;

    @FXML
    public void onclick(ActionEvent actionEvent) {
        t1.setText("hello !!");
        if(flag){//取消状态下的点击 重新开始任务
            flag= !flag;
             task=   firstLineService.reCreate();
            p1.progressProperty().bind(task.progressProperty());
            firstLineService.executeTask(task);
        }
        else {
            flag= !flag;
            task.cancel();

        }

    }


    void init(Task task,FirstLineService firstLineService) {
        this.task=task;
        this.firstLineService=firstLineService;
        p1.progressProperty().bind(task.progressProperty());
    }
}
